# wolfSSL STM32 Example for System Workbench for STM32 (Open STM32 Tools)

This example has been deprecated and moved to `IDE/STM32Cube`.
