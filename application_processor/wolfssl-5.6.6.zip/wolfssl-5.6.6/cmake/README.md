# wolfSSL CMake

This directory contains some supplementary functions for the [CMakeLists.txt](../CMakeLists.txt) in the root.

See also cmake notes in the [INSTALL](../INSTALL) documentation file.


